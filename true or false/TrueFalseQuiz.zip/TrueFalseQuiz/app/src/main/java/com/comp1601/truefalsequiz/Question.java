package com.comp1601.truefalsequiz;

/**
 * Created by jiangruida on 2018-01-30.
 */

public class Question {
    private String mQuestion;
    private String mAnswer;


    public Question(String aQuestionAnswerString){
        int index = aQuestionAnswerString.indexOf("[");
        mQuestion = aQuestionAnswerString.substring(0,index);
        mAnswer = aQuestionAnswerString.substring(index+1,aQuestionAnswerString.length()-1);
        //aQuestionAnswerString is expected to be of the form:
        //"Is Java an Object-Oriented Language?[Yes]"
    }
    public String getQuestion(){
        return mQuestion;
    }
    public String getAnswer() {
        return mAnswer;
    }

}