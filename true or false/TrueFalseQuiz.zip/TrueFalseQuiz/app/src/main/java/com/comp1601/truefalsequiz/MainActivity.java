package com.comp1601.truefalsequiz;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import android.graphics.Color;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private Button mAButton;
    private Button mBButton;
    private Button mCButton;
    private Button mDButton;
    private Button mEButton;
    private Button mPREVButton;
    private Button mSUBMITButton;
    private Button mNEXTButton;
    private int mCurrentQuestionIndex = 0;
    private  final String TAG = this.getClass().getSimpleName() + " @" + System.identityHashCode(this);
    TextView mQuestionTextView;
    ArrayList<Question> mQuestions;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mAButton = (Button) findViewById(R.id.A_button);
        mBButton = (Button) findViewById(R.id.B_button);
        mCButton = (Button) findViewById(R.id.C_button);
        mDButton = (Button) findViewById(R.id.D_button);
        mEButton = (Button) findViewById(R.id.E_button);
        mPREVButton = (Button) findViewById(R.id.PREV_button);
        mSUBMITButton = (Button) findViewById(R.id.SUBMIT_button);
        mNEXTButton = (Button) findViewById(R.id.NEXT_button);
        mQuestions = new ArrayList<Question>();
        mQuestionTextView = (TextView) findViewById(R.id.question_text_view);

        mQuestions.add(new Question(getString(R.string.question1)));
        mQuestions.add(new Question(getString(R.string.question2)));
        mQuestions.add(new Question(getString(R.string.question3)));
        mQuestions.add(new Question(getString(R.string.question4)));
        mQuestions.add(new Question(getString(R.string.question5)));
        mQuestions.add(new Question(getString(R.string.question6)));
        mQuestions.add(new Question(getString(R.string.question7)));
        mQuestions.add(new Question(getString(R.string.question8)));
        mQuestions.add(new Question(getString(R.string.question9)));
        mQuestions.add(new Question(getString(R.string.question10)));

        mQuestionTextView.setText(mQuestions.get(mCurrentQuestionIndex).getQuestion());

        for(Question q: mQuestions) {
            System.out.println("Q:" + q.getQuestion() + "A: " + q.getAnswer());
        }
        Log.i(TAG, "onCreate()");

        mAButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                mAButton.setBackgroundColor(Color.RED);
                mBButton.setBackgroundColor(Color.rgb(214,215,215));
                mCButton.setBackgroundColor(Color.rgb(214,215,215));
                mDButton.setBackgroundColor(Color.rgb(214,215,215));
                mEButton.setBackgroundColor(Color.rgb(214,215,215));
                Log.i(TAG,"A Button Pressed");

                if(mCurrentQuestionIndex >= mQuestions.size()) mCurrentQuestionIndex = 0;
                mQuestionTextView.setText(mQuestions.get(mCurrentQuestionIndex).getQuestion());

            }
        });
        mBButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                mAButton.setBackgroundColor(Color.rgb(214,215,215));
                mBButton.setBackgroundColor(Color.RED);
                mCButton.setBackgroundColor(Color.rgb(214,215,215));
                mDButton.setBackgroundColor(Color.rgb(214,215,215));
                mEButton.setBackgroundColor(Color.rgb(214,215,215));
                Log.i(TAG,"B Button Pressed");

                if(mCurrentQuestionIndex >= mQuestions.size()) mCurrentQuestionIndex = 0;
                mQuestionTextView.setText(mQuestions.get(mCurrentQuestionIndex).getQuestion());

            }
        });
        mCButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                mAButton.setBackgroundColor(Color.rgb(214,215,215));
                mBButton.setBackgroundColor(Color.rgb(214,215,215));
                mCButton.setBackgroundColor(Color.RED);
                mDButton.setBackgroundColor(Color.rgb(214,215,215));
                mEButton.setBackgroundColor(Color.rgb(214,215,215));
                Log.i(TAG,"C Button Pressed");

                if(mCurrentQuestionIndex >= mQuestions.size()) mCurrentQuestionIndex = 0;
                mQuestionTextView.setText(mQuestions.get(mCurrentQuestionIndex).getQuestion());

            }
        });
        mDButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                mAButton.setBackgroundColor(Color.rgb(214,215,215));
                mBButton.setBackgroundColor(Color.rgb(214,215,215));
                mCButton.setBackgroundColor(Color.rgb(214,215,215));
                mDButton.setBackgroundColor(Color.RED);
                mEButton.setBackgroundColor(Color.rgb(214,215,215));
                Log.i(TAG,"D Button Pressed");

                if(mCurrentQuestionIndex >= mQuestions.size()) mCurrentQuestionIndex = 0;
                mQuestionTextView.setText(mQuestions.get(mCurrentQuestionIndex).getQuestion());

            }
        });
        mEButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                mAButton.setBackgroundColor(Color.rgb(214,215,215));
                mBButton.setBackgroundColor(Color.rgb(214,215,215));
                mCButton.setBackgroundColor(Color.rgb(214,215,215));
                mDButton.setBackgroundColor(Color.rgb(214,215,215));
                mEButton.setBackgroundColor(Color.RED);
                /*Log.i(TAG,"E Button Pressed");
                if(mQuestions.get(mCurrentQuestionIndex).getAnswer().equals("E")) {
                    Toast.makeText(MainActivity.this,
                            R.string.correct_answer_toast,
                            Toast.LENGTH_SHORT).show();
                }
                else{
                    Toast.makeText(MainActivity.this,
                            R.string.wrong_answer_toast,
                            Toast.LENGTH_SHORT).show();
                }*/
                //mCurrentQuestionIndex++;
                if(mCurrentQuestionIndex >= mQuestions.size()) mCurrentQuestionIndex = 0;
                mQuestionTextView.setText(mQuestions.get(mCurrentQuestionIndex).getQuestion());

            }
        });
        mPREVButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Log.i(TAG, "PREV Button Pressed");
                mAButton.setBackgroundColor(Color.rgb(214,215,215));
                mBButton.setBackgroundColor(Color.rgb(214,215,215));
                mCButton.setBackgroundColor(Color.rgb(214,215,215));
                mDButton.setBackgroundColor(Color.rgb(214,215,215));
                mEButton.setBackgroundColor(Color.rgb(214,215,215));
                if((mCurrentQuestionIndex > 0)){
                mCurrentQuestionIndex--;
                    if (mCurrentQuestionIndex >= mQuestions.size()) mCurrentQuestionIndex = 0;
                    mQuestionTextView.setText(mQuestions.get(mCurrentQuestionIndex).getQuestion());
                }
                }
    });

        mSUBMITButton.setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick (View v) {
            ArrayList result = new ArrayList();

            String submit = getString(R.string.SUBMIT_button_label);
            for(int i=0;i<=10;i++){
                result.add(i);

                 }
                }
            });


        mNEXTButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Log.i(TAG, "NEXT Button Pressed");
                mAButton.setBackgroundColor(Color.rgb(214,215,215));
                mBButton.setBackgroundColor(Color.rgb(214,215,215));
                mCButton.setBackgroundColor(Color.rgb(214,215,215));
                mDButton.setBackgroundColor(Color.rgb(214,215,215));
                mEButton.setBackgroundColor(Color.rgb(214,215,215));

                if((mCurrentQuestionIndex <= 10)) {
                    mCurrentQuestionIndex++;
                    if (mCurrentQuestionIndex >= mQuestions.size()) mCurrentQuestionIndex = 0;
                    mQuestionTextView.setText(mQuestions.get(mCurrentQuestionIndex).getQuestion());
                }
                }
        });
            }
    @Override
    protected void onStart(){
        super.onStart();
        Log.i(TAG, "onStart()") ;
    }
    @Override
    protected void onResume(){
        super.onResume();
        Log.i(TAG, "onResume()") ;
    }
    @Override
    protected void onPause(){
        super.onPause();
        Log.i(TAG, "onPause()") ;
    }
    @Override
    protected void onStop(){
        super.onStop();
        Log.i(TAG, "onStop()") ;
    }
    @Override
    protected void onDestroy(){
        super.onDestroy();
        Log.i(TAG, "onDestroy()") ;
    }
}
